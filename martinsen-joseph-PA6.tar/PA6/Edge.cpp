#include "Edge.hpp"

Edge::Edge(int start, int end, int weight)
{
    this->start = start;
    this->end = end;
    this->weight = weight;
}